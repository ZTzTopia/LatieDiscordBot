module.exports = {
    name: "advice",
    aliases: [],
    description: "Gives a random life advice.",
    cooldown: [],
    usage: [],
    example: []
};

var unirest = require('unirest');
const { MessageEmbed } = require("discord.js");

module.exports.run = async (client, message, args) => {
	unirest.get('https://api.adviceslip.com/advice').end(result => {
        var body = JSON.parse(result.body);
        var embed = new MessageEmbed()
            .setTitle(`Advice slip #${body.slip.id}`)
            .setDescription(body.slip.advice)
            .setFooter('Powered by adviceslip.com')
            .setTimestamp();

        message.channel.send({ embed: embed });
    });
}
