module.exports = {
    name: "say",
    aliases: [],
    description: "Makes the bot repeat your message..",
    cooldown: [],
    usage: ['<message>'],
    example: ['Hello, World!']
};

module.exports.run = async (client, message, args, suffix) => {
    if(!args[0]) return;

    message.delete();
	message.channel.send(suffix);
}
