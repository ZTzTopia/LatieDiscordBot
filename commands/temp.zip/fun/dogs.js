module.exports = {
    name: "dogs",
    aliases: [],
    description: "Gives a random cute dog images.",
    cooldown: [],
    usage: [],
    example: []
};

const { MessageEmbed } = require('discord.js');
const unirest = require('unirest');

module.exports.run = async (client, message, args) => {
	unirest.get('https://random.dog/woof.json?filter=mp4,webm').end(result => {
        var body = result.body;
        var embed = new MessageEmbed()
            .setTitle("Oh look I found a cuty dog :dog:")
            .setImage(body.url)
            .setFooter(`Powered by random.dog`)
            .setTimestamp();

        message.channel.send({ embed: embed });
    });
}