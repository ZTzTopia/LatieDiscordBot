module.exports = {
    name: "bunny",
    aliases: [],
    description: "Gives a random cute bunny images.",
    cooldown: [],
    usage: [],
    example: []
};

var unirest = require('unirest');
const { MessageEmbed } = require("discord.js");

module.exports.run = async (client, message, args) => {
    unirest.get('https://api.bunnies.io/v2/loop/random/?media=webm,mp4').end(result => {
        var body = result.body;
        var embed = new MessageEmbed()
            .setTitle(`Bunny's #${body.id}`)
            .setURL(`https://api.bunnies.io/v2/loop/ ${body.id} /?media=webm,mp4`)
            .setImage(body.media.poster)
            .setFooter('Powered by api.bunnies.io')
            .setTimestamp();

        message.channel.send({ embed: embed });
    });
}
