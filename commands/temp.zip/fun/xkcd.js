module.exports = {
    name: "xkcd",
    aliases: [],
    description: "Fetches random or specific XKCD comics.",
    cooldown: [],
    usage: ['[latest|id]'],
    example: ['latest', '453']
};

const { MessageEmbed } = require('discord.js');
const got = require('got');
const errors = require("../../module/errors.js");

module.exports.run = async (client, message, args) => {
    let id;
    if(args[0] !== 'latest')
    {
        id = parseInt(args[0]);
        if(!isNaN(id))
        {
            const latest = await getLatest();
            const maxComic = latest.num;
            if(id < 0 || id > maxComic) 
                return errors.customText(message, "XKCD Comic not found.");
        }
        else id = await getRandom();
    }
    else id = (await getLatest()).num;

    while(id === '404 Not Found')
        id = await getRandom();

    const info = await getInfo(id);
    let embed = new MessageEmbed()
        .setTitle(`[${id}] ${info.title}`)
        .setURL(`http://xkcd.com/${id}`)
        .setDescription(`**${info.alt}**` || `Nothing`)
        .addField(`Upload On:`, `${info.day}-${info.month}-${info.year}` || `None`)
        .setImage(info.img)
        .setFooter(`Powered by xkcd.com`)
        .setTimestamp();

    message.channel.send({ embed: embed });
}

async function getInfo(id) 
{
    return (await got(`http://xkcd.com/${id}/info.0.json`, { json: true })).body;
}

async function getLatest() 
{
    return (await got('http://xkcd.com/info.0.json', { json: true })).body;
}

async function getRandom() 
{
    const latest = await getLatest();
    const max = latest.num;

    return Math.floor(Math.random() * max);
}
