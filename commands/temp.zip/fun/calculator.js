module.exports = {
    name: "calculate",
    aliases: ['calc'],
    description: "Calculate a expression math.",
    cooldown: [],
    usage: ['<question>'],
    example: ['100 + 100', '100 * 100', '100 / 100']
};

const { MessageEmbed } = require("discord.js");
const math = require('math-expression-evaluator');
const help = require("../../module/help.js");

module.exports.run = async (client, message, args) => {
    if(!args[0]) return help.help(message, 'calculate');

    const question = args.join(' ');

    let answer;
    try {
        answer = math.eval(question);
    } catch (e) {
        return message.channel.send(`Error: \n\`\`\` ${err} \`\`\``);
    }

    let embed = new MessageEmbed()
        .addField('Equation:', `\n\`\`\`\n${question}\n\`\`\``)
        .addField('Answer:', `\n\`\`\`\n${answer}\n\`\`\``)

    message.channel.send({ embed: embed });
}
