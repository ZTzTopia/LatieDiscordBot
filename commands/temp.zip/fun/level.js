module.exports = {
    name: "level",
    aliases: [],
    description: "Get your level information in a server.",
    cooldown: [],
    usage: [],
    example: []
};

const { MessageEmbed } = require("discord.js");

module.exports.run = async (client, message, args, suffix, db) => {
    var playerCalled = message.mentions.members.first() || message.guild.members.cache.get(args[0] || message.author.id);
    db.query(`SELECT * FROM xp WHERE gid = '${message.guild.id}' AND uid = '${playerCalled.id}'`, (err, result) => {
        if(!err)
        {
            if(result > 1)
            {   
                let embed = new MessageEmbed()
                  .addField('Level', `${result[0].level}`)
                  .addField('Xp', `${result[0].xp}/${result[0].mathXp}`)
                  .setFooter(playerCalled.user.tag, playerCalled.user.avatarURL)
                  .setTimestamp();

                message.channel.send({ embed: embed });
            }
            else message.channel.send("That user not have xp.");
        }
        else message.channel.send(`Error: \n\`\`\` ${err} \`\`\``);
    });
};
