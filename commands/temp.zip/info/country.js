module.exports = {
    name: "country",
    aliases: [],
    description: "Gets information about a country. ",
    cooldown: [],
    usage: ['<country>'],
    example: ["Indonesia"]
};

const { MessageEmbed } = require("discord.js");
const unirest = require("unirest");
const errors = require("../../module/errors.js");
const help = require("../../module/help.js");

module.exports.run = async (client, message, args, suffix) => {
    unirest.get("https://restcountries.eu/rest/v2/name/" + suffix + "?fullText=true").end(result => {
        var body = result.body;

        if(!body) return help.help(message, 'country');
        else if(body.status === 404) return errors.resStatus(message, "404");

        for(let i = 0; i < body.length; i++) 
        {
            const embed = new MessageEmbed()
                .setTitle(body[i].name)
                .setAuthor(message.author.tag, message.author.avatarURL)
                .setDescription("Country Information")
                .addField("Capital", body[i].capital || "N/A", true)
                .addField("Domain", body[i].alpha2Code || "N/A" + ", " + body[i].alpha3Code || "N/A", true)
                .addField("Calling Code", `+${body[i].callingCodes}`, true)
                .addField("Region", body[i].region || "N/A")
                .addField("Subregion", body[i].subregion || "N/A")
                .addField("Population", body[i].population || "N/A")
                .addField("Area", `${body[i].area} Square Kilometers` || "N/A")
                .addField("Timezones", body[i].timezones.join(", ") || "N/A")
                .addField("Borders", body[i].borders.join(", ") || "N/A", true)
                .addField("Native Name", body[i].nativeName || "N/A", true)
                .addField("Demonym", body[i].demonym || "N/A", true)
                .addField("Alternate Names", body[i].altSpellings.join(", ") || "N/A")
                .addField("Flag", body[i].flag || "N/A")
                .setFooter("Powered by restcountries.eu")
                .setTimestamp();

            message.channel.send({ embed: embed });
        }
    });
};
