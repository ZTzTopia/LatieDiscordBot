module.exports = {
    name: "serverinfo",
    description: "Provides the server information.",
    cooldown: [],
    usage: [],
    example: []
};

const { MessageEmbed } = require('discord.js');
const dateFormat = require('dateformat');

module.exports.run = async (client, message) => {
    var date = new Date(message.guild.createdAt);
    date = `${new Date().getUTCFullYear() - date.getUTCFullYear()}y ${date.getUTCMonth()}m ${date.getUTCDate() - 1}d ${date.getUTCHours()}h ${date.getUTCMinutes()}m ${date.getUTCSeconds()}s`;

    const verificationLevels = ['None', 'Low', 'Medium', 'Insane', 'Extreme'];

    var members = 0, bots = 0, online = 0;

    message.guild.members.cache.forEach(member => {
        if(member.user.bot) bots++;
        else members++;

        if(member.user.presence.status === "online") online++;
    });

    const embed = new MessageEmbed()
        .setTitle(message.guild.name)
        .setThumbnail(message.guild.iconURL)
        .addField('Owner', message.guild.owner.name, true)
        .addField('Region', message.guild.region, true)
        .addField('Created', dateFormat(message.guild.createdAt), true)
        .addField('Date since creation', `Last ${date}`, true)
        .addField('Total Members', message.guild.memberCount, true)
        .addField('Members Online', `${online}/${message.guild.memberCount}`, true)
        .addField('User Count', members, true)
        .addField('Bot Count', bots, true)
        .addField('Text Channels', `${message.guild.channels.cache.filter(m => m.type === 'text').size}`, true)
        .addField('Voice Channels', `${message.guild.channels.cache.filter(m => m.type === 'voice').size}`, true)
        .addField('Channel Count', message.guild.channels.cache.size, true)
        .addField('Verification Level', `${verificationLevels[message.guild.verificationLevel]}`, true)
        .setTimestamp()
        .setFooter(`Guild ID: ${message.guild.id}`);
    
    message.channel.send({ embed: embed });
}
